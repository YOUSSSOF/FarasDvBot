INSERT INTO "users" ("id", "tel_id", "first_name", "username", "points") VALUES
(1, 1129145429, 'ƳƠƲƧƠƑ', 'YOUDEXSOF', 1);
INSERT INTO "users" ("id", "tel_id", "first_name", "username", "points") VALUES
(2, 5730422589, 'FarasDv Support', 'FarasDvSupport', 0);
INSERT INTO "users" ("id", "tel_id", "first_name", "username", "points") VALUES
(3, 1084993626, 'ᵃᵇᵇᵃˢ', 'AbasYzd', 0);
INSERT INTO "users" ("id", "tel_id", "first_name", "username", "points") VALUES
(4, 1205883528, '𝑺𝒂𝒋𝒂𝒅', 'realsjd', 0),
(5, 708190957, 'āli', NULL, 0),
(6, 740294268, 'Meisam', 'MeisamGh9', 0),
(7, 1984275140, 'Saman', NULL, 0),
(8, 90701209, 'SeYeD', 'Komeil2005', 0),
(9, 668226929, 'Scorpion', 'Ashkan0621', 0);